﻿// Name - Amritpal Singh
// FileName - Program.cs
// Project - A05_WAMP_DEMO
// Date - 12 November 2021
// Description - This File execute the client side logic for Assignment 5 Game.





using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace TCPIPClient
{
    // Class - Program
    // Description - This is the main class of the Project
    class Program
    {
        static void Main(string[] args)
        {
            ConnectClient("127.0.0.1");
            Console.ReadLine();
        }
        static void ConnectClient(String server)
        {
            try
            {
                Int32 port = 13000;
                TcpClient client = new TcpClient(server, port);

                NetworkStream stream = client.GetStream();
                Byte[] data = new byte[256];
                String responseData = String.Empty;
                while (true)
                {
                    Int32 bytes = stream.Read(data, 0, data.Length);
                    responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
                    if (responseData[0] == 'Y' && responseData[1] == 'A')
                    {
                        String strPlayAgainOption = Console.ReadLine();
                        Byte[] data1 = System.Text.Encoding.ASCII.GetBytes(strPlayAgainOption);
                        stream.Write(data1, 0, data1.Length);
                        if(strPlayAgainOption == "Yes")
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                    Console.WriteLine("{0}", responseData);
                    int n1Index = responseData.IndexOf("of ");
                    int n2Index = responseData.IndexOf(" to ");
                    int n3Index = responseData.IndexOf("\nChoose");
                    int len = n2Index - (n1Index + 3);
                    int len1 = n3Index - (n2Index + 4);
                    string subMsg = responseData.Substring(n1Index + 3, len);
                    string subMsg1 = responseData.Substring(n2Index + 4, len1);
                    int minRangeByServer = 0;
                    int maxRangeByServer = 0;
                    bool itIsInt1 = int.TryParse(subMsg, out minRangeByServer);
                    bool itIsInt2 = int.TryParse(subMsg1, out maxRangeByServer);


                    int iUserChoosedNumber = 0;
                    bool itIsInt = false;
                    while (!itIsInt)
                    {
                        String strUserChoosedNumber = Console.ReadLine();
                        itIsInt = int.TryParse(strUserChoosedNumber, out iUserChoosedNumber);
                        if ((iUserChoosedNumber >= 0) && (itIsInt) && (iUserChoosedNumber >= minRangeByServer) && (iUserChoosedNumber <= maxRangeByServer))
                        {

                            Byte[] data1 = System.Text.Encoding.ASCII.GetBytes(strUserChoosedNumber);
                            stream.Write(data1, 0, data1.Length);
                            break;
                        }
                        else
                        {
                            Console.WriteLine("ERROR: You must enter a valid positive interger number in the given Range.....Choose your Number Again");
                        }
                    }

                    
                }
                stream.Close();
                client.Close();
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine("ArgumentNullException: {0}", e);
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }

        }
    }
}
