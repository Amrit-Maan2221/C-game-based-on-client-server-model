﻿// Name - Amritpal Singh
// FileName - Program.cs
// Project - A05_WAMP_DEMO
// Date - 12 November 2021
// Description - This File execute the server side logic for Assignment 5 Game.




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;



namespace TCPIPServer
{
    // Class - Program
    // Description - This is the main class of the Project
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = null;
            try
            {
                // Set the TcpListener on port 13000.
                Int32 port = 13000;
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");

                // TcpListener server = new TcpListener(port);
                server = new TcpListener(localAddr, port);

                // Start listening for client requests.
                server.Start();


                // Enter the listening loop.
                while (true)
                {
                    Console.Write("Waiting for a connection... ");

                    // Perform a blocking call to accept requests.
                    // You could also user server.AcceptSocket() here.
                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine("Connected!");

                    ParameterizedThreadStart ts = new ParameterizedThreadStart(Worker);
                    Thread clientThread = new Thread(ts);
                    clientThread.Start(client);


                }
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }
            finally
            {
                // Stop listening for new clients.
                server.Stop();
            }


            Console.WriteLine("\nHit enter to continue...");
            Console.Read();
        }





        // Function Name - public static void Worker(Object o)
        // Description - Implement the server side game logic
        // Paramerter - Object o --> Any object
        // Returns - void --> Nothing
        public static void Worker(Object o)
        {
            var minRange = 1;
            var maxRange = 10000;
            bool playAgain = false;
            TcpClient client = (TcpClient)o;
            String serverAns = "";
            do
            {
                if(playAgain == true)
                {
                    minRange = 1;
                    maxRange = 10000;
                    serverAns = "";
                }
                // Creating random number logic
                System.Random random = new System.Random();
                minRange = random.Next(minRange, maxRange);
                maxRange = random.Next(minRange, maxRange);
                if (minRange > maxRange)
                {
                    var temp = minRange;
                    minRange = maxRange;
                    maxRange = temp;
                }
                //asking user to enter a number between given number
                String serverResonse = serverAns + string.Format("You can choose a integer number from a range of {0} to {1}\nChoose Your number and then press enter: \n", minRange, maxRange);

                
                // Buffer for reading data
                Byte[] bytes = new Byte[256];
                String data = null;

                // Get a stream object for reading and writing
                NetworkStream stream = client.GetStream();



                byte[] msg = System.Text.Encoding.ASCII.GetBytes(serverResonse);

                // Send back a response.
                stream.Write(msg, 0, msg.Length);


                int i = 0;
                while (i == 0)
                {
                    stream.Flush();
                    // Translate data bytes to a ASCII string.
                    i = stream.Read(bytes, 0, bytes.Length);
                }
                data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                int iUserChoosedNumber = 0;
                bool itIsInt = int.TryParse(data, out iUserChoosedNumber);

                Console.WriteLine("Received: {0}", data);

                // Determining that where the guess was close or not
                var computerGuessNumber = random.Next(minRange, maxRange);  
                var rangeDifference = maxRange - minRange;                    
                int guessCloseness = rangeDifference / 100;                    
                
                if (computerGuessNumber == iUserChoosedNumber)
                {
                    serverAns = "YAAAAAHOOO!!!!Congrats you have won the game\n" + "Do you want to play ?   ...Press Yes to play Again!!!!\n" ;

                    msg = System.Text.Encoding.ASCII.GetBytes(serverAns);

                    // Send back a response.
                    stream.Write(msg, 0, msg.Length);

                    stream.Flush();
                    // Translate data bytes to a ASCII string.
                    i = stream.Read(bytes, 0, bytes.Length);
                    data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                    if(data == "Yes")
                    {
                        playAgain = true;
                        continue;
                    }
                    else
                    {
                        playAgain = false;
                        break;
                    }
                }
                else if ((iUserChoosedNumber - guessCloseness <= computerGuessNumber) && (iUserChoosedNumber > computerGuessNumber))
                {
                    serverAns = "Aww! Your Guess is just a little high!!! Try agian with updated range\n";
                    maxRange = iUserChoosedNumber;
                    
                }
                else if (iUserChoosedNumber > computerGuessNumber)
                {
                    serverAns = "Ouch! Your Guess is just a very high!!! Try agian with updated range\n";
                    maxRange = iUserChoosedNumber;
                   
                }
                else if ((iUserChoosedNumber + guessCloseness >= computerGuessNumber) && (iUserChoosedNumber > computerGuessNumber))
                {
                    serverAns = "Aww! Your Guess is just a little low!!! Try agian with updated range\n";
                    minRange = iUserChoosedNumber;
                    
                }
                else
                {
                    serverAns = "Ouch! Your Guess is just a very low!!! Try again with updated range\n";
                    minRange = iUserChoosedNumber;
                    
                }
                playAgain = false;
            } while (true);



            
            // Shutdown and end connection
            client.Close();
        }

    }
}
